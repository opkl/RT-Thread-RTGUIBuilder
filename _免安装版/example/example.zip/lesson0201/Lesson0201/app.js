var app = {
page : "page1/page1"
};
App(app);
