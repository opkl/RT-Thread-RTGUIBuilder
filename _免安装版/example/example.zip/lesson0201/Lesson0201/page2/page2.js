var page = {
	onButton : function(e) {
		pm.navigateBack();
	}
};

Page(page);
