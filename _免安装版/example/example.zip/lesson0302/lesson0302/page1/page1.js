var page = {
};

Page(page);
