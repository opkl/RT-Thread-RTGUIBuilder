var page = {
    onLoad : function()
    {
        this.setData({listctrl1 : {page : this, xml : 'Panels/item', items : [{imagebox1 : "1.png", label1 : "1.png"},
                                                                              {imagebox1 : "2.png", label1 : "2.png"},
                                                                              {imagebox1 : "3.png", label1 : "3.png"},
                                                                              {imagebox1 : "4.png", label1 : "4.png"},
                                                                              {imagebox1 : "5.png", label1 : "5.png"},
                                                                              {imagebox1 : "6.png", label1 : "6.png"},
                                                                              {imagebox1 : "7.png", label1 : "7.png"},
                                                                              {imagebox1 : "8.png", label1 : "8.png"},
                                                                              {imagebox1 : "9.png", label1 : "9.png"} ]}})
    }
};

Page(page);
